import pandas as pd
import numpy as np
from sklearn.model_selection import KFold
from xgboost import XGBRegressor
import os
from utils import calculate_smape

class ModelTrainer:
    def __init__(self, config):
        self.config = config
    
    def train_and_validate(self, X_train, y_train):
        """Train model with cross-validation"""
        model = XGBRegressor(**self.config.model_params)
        kf = KFold(n_solds=self.config.n_folds, shuffle=True, random_state=self.config.random_state)
        
        cv_scores = []
        print("📊 Cross-validation results:")
        
        for fold, (train_idx, val_idx) in enumerate(kf.split(X_train)):
            X_tr, X_val = X_train[train_idx], X_train[val_idx]
            y_tr, y_val = y_train.iloc[train_idx], y_train.iloc[val_idx]
            
            model.fit(X_tr, y_tr)
            
            val_pred = np.expm1(model.predict(X_val))
            val_true = np.expm1(y_val)
            fold_smape = calculate_smape(val_true, val_pred)
            cv_scores.append(fold_smape)
            
            print(f"   Fold {fold+1} SMAPE: {fold_smape:.2f}%")
        
        cv_mean = np.mean(cv_scores)
        print(f"✅ Average SMAPE: {cv_mean:.2f}%")
        
        # Train final model on all data
        final_model = XGBRegressor(**self.config.model_params)
        final_model.fit(X_train, y_train)
        
        return cv_mean, final_model
    
    def predict(self, model, X_test, price_bounds, train_data):
        """Generate predictions with post-processing"""
        test_pred_log = model.predict(X_test)
        predictions = np.expm1(test_pred_log)
        
        # Apply bounds
        predictions = np.clip(predictions, price_bounds.iloc[0], price_bounds.iloc[1])
        predictions = np.maximum(predictions, 0.1)
        
        # Distribution matching
        predictions = self._match_distribution(predictions, train_data['price'])
        
        return predictions
    
    def _match_distribution(self, predictions, train_prices):
        """Match prediction distribution to training distribution"""
        train_q = np.percentile(train_prices, np.linspace(0, 100, 21))
        test_q = np.percentile(predictions, np.linspace(0, 100, 21))
        
        for i in range(1, len(train_q)-1, 2):
            lower_bound = np.percentile(predictions, i*5)
            mask = predictions <= lower_bound
            predictions[mask] = np.percentile(train_prices, i*5)
        
        # Light blending with median
        train_median = train_prices.median()
        predictions = 0.95 * predictions + 0.05 * train_median
        
        return predictions
    
    def create_submission(self, test_data, predictions):
        """Create submission file"""
        submission = pd.DataFrame({
            'sample_id': test_data['sample_id'],
            'price': predictions
        })
        
        submission_path = os.path.join(self.config.outputs_path, 'final_submission.csv')
        submission.to_csv(submission_path, index=False)
        
        return submission_path