import pandas as pd
import numpy as np
import os

class DataLoader:
    def __init__(self, config):
        self.config = config
    
    def load_data(self):
        """Load train and test data"""
        train_path = os.path.join(self.config.dataset_path, 'train.csv')
        test_path = os.path.join(self.config.dataset_path, 'test.csv')
        
        train = pd.read_csv(train_path).reset_index(drop=True)
        test = pd.read_csv(test_path).reset_index(drop=True)
        
        print(f"📊 Loaded: Train {len(train)}, Test {len(test)}")
        return train, test
    
    def clean_data(self, train, test):
        """Clean and preprocess data"""
        # Remove price outliers
        price_q = train['price'].quantile([0.01, 0.99])
        train = train[
            (train['price'] >= price_q.iloc[0]) & 
            (train['price'] <= price_q.iloc[1])
        ].reset_index(drop=True)
        
        # Remove duplicates
        train = train.drop_duplicates(subset=['image_link'], keep='first')
        test = test.drop_duplicates(subset=['image_link'], keep='first')
        
        # Remove short descriptions
        train = train[train['catalog_content'].str.len() > 20]
        test = test[test['catalog_content'].str.len() > 20]
        
        print(f"🧹 Cleaned: Train {len(train)}, Test {len(test)}")
        return train.reset_index(drop=True), test.reset_index(drop=True), price_q