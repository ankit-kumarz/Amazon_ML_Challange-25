class Config:
    def __init__(self):
        # Paths
        self.base_path = '/content/drive/MyDrive/Smart_Product_Pricing_2025'
        self.dataset_path = f"{self.base_path}/dataset"
        self.outputs_path = f"{self.base_path}/outputs"
        
        # Model parameters
        self.model_params = {
            'n_estimators': 400,
            'max_depth': 6,
            'learning_rate': 0.03,
            'reg_alpha': 0.1,
            'reg_lambda': 0.5,
            'subsample': 0.8,
            'colsample_bytree': 0.8,
            'random_state': 42,
            'n_jobs': -1
        }
        
        # Feature parameters
        self.tfidf_params = {
            'max_features': 3000,
            'ngram_range': (1, 3),
            'stop_words': 'english',
            'min_df': 3,
            'max_df': 0.7
        }
        
        # Cross-validation
        self.n_folds = 3
        self.random_state = 42
        
        # Create directories
        self._create_directories()
    
    def _create_directories(self):
        os.makedirs(self.outputs_path, exist_ok=True)