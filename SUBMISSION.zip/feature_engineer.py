import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from scipy import sparse
import re

class FeatureEngineer:
    def __init__(self, config):
        self.config = config
        self.vectorizer = None
    
    def create_features(self, train, test):
        """Create all features for train and test"""
        # Text features
        X_train_text, self.vectorizer = self._text_features(train, is_train=True)
        X_test_text = self._text_features(test, is_train=False)[0]
        
        # Image features
        X_train_img = self._image_features(train)
        X_test_img = self._image_features(test)
        
        # Combine features
        X_train = sparse.hstack([X_train_text, sparse.csr_matrix(X_train_img.values)], format='csr')
        X_test = sparse.hstack([X_test_text, sparse.csr_matrix(X_test_img.values)], format='csr')
        
        # Target variable
        y_train = np.log1p(train['price'])
        
        print(f"🔧 Features: Train {X_train.shape}, Test {X_test.shape}")
        return X_train, X_test, y_train
    
    def _text_features(self, df, is_train=True):
        """Create text features using TF-IDF and manual features"""
        texts = df['catalog_content'].fillna('').str.lower()
        
        # TF-IDF features
        if is_train:
            self.vectorizer = TfidfVectorizer(**self.config.tfidf_params)
            tfidf = self.vectorizer.fit_transform(texts)
        else:
            tfidf = self.vectorizer.transform(texts)
        
        # Manual text features
        manual_features = self._create_manual_features(texts)
        
        # Combine
        features = sparse.hstack([tfidf, sparse.csr_matrix(manual_features.values)], format='csr')
        return features, self.vectorizer
    
    def _create_manual_features(self, texts):
        """Create manual text-based features"""
        features = pd.DataFrame({
            'word_count': texts.str.split().str.len(),
            'char_count': texts.str.len(),
            'digit_count': texts.str.count(r'\d'),
            'has_brand': texts.str.contains('apple|samsung|sony|nike|nestle|amul', regex=True).astype(int),
            'has_food': texts.str.contains('rice|wheat|oil|sugar|tea|coffee|chocolate', regex=True).astype(int),
            'has_electronics': texts.str.contains('phone|laptop|charger|headphone|tv', regex=True).astype(int),
            'has_furniture': texts.str.contains('sofa|bed|chair|table|shelf', regex=True).astype(int),
            'has_quantity': texts.str.contains(r'\d+\s*(?:g|kg|ml|pack|pcs)', regex=True).astype(int),
            'is_premium': texts.str.contains('premium|luxury|high-end|organic', regex=True).astype(int),
            'has_discount': texts.str.contains('discount|sale|offer', regex=True).astype(int)
        })
        return features
    
    def _image_features(self, df):
        """Create simple image features from URLs"""
        urls = df['image_link'].fillna('').astype(str)
        
        features = pd.DataFrame({
            'url_length': urls.str.len(),
            'is_amazon': urls.str.contains('amazon', case=False).astype(int),
            'has_jpg': urls.str.contains('jpg', case=False).astype(int),
            'num_segments': urls.str.count('/'),
            'has_id': urls.str.contains(r'\d{5,}', regex=True).astype(int)
        })
        return features