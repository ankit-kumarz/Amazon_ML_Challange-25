#!/usr/bin/env python3
"""
Smart Product Pricing - One Click Runner
Run this file to execute the complete pipeline
"""

from main import main

if __name__ == "__main__":
    print("🎯 SMART PRODUCT PRICING - ONE CLICK EXECUTION")
    print("Target SMAPE: ~50%")
    print("=" * 50)
    main()