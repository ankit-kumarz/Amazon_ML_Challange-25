import numpy as np

def calculate_smape(y_true, y_pred):
    """Calculate SMAPE metric"""
    return 100 * np.mean(2 * np.abs(y_pred - y_true) / (np.abs(y_true) + np.abs(y_pred) + 1e-8))

def print_summary(train_data, test_data, predictions):
    """Print summary statistics"""
    print("\n📈 PREDICTION SUMMARY:")
    print(f"   Training data mean price: ${train_data['price'].mean():.2f}")
    print(f"   Predictions mean price: ${predictions.mean():.2f}")
    print(f"   Predictions range: ${predictions.min():.2f} - ${predictions.max():.2f}")
    print(f"   Predictions std: ${predictions.std():.2f}")