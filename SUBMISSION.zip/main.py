# ============================================
# SMART PRODUCT PRICING - OPTIMIZED PIPELINE
# Target: ~50% SMAPE Score
# ============================================

import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import KFold
from xgboost import XGBRegressor
from scipy import sparse
import os
import warnings
warnings.filterwarnings('ignore')

from config import Config
from data_loader import DataLoader
from feature_engineer import FeatureEngineer
from model_trainer import ModelTrainer
from utils import calculate_smape

def main():
    print("🚀 SMART PRODUCT PRICING PIPELINE STARTED")
    print("=" * 50)
    
    # Initialize components
    config = Config()
    data_loader = DataLoader(config)
    feature_engineer = FeatureEngineer(config)
    model_trainer = ModelTrainer(config)
    
    # Load data
    print("📁 Loading data...")
    train, test = data_loader.load_data()
    
    # Clean data
    print("🧹 Cleaning data...")
    train, test, price_bounds = data_loader.clean_data(train, test)
    
    # Feature engineering
    print("🔧 Engineering features...")
    X_train, X_test, y_train = feature_engineer.create_features(train, test)
    
    # Model training and validation
    print("🤖 Training model...")
    cv_score, model = model_trainer.train_and_validate(X_train, y_train)
    
    # Generate predictions
    print("🎯 Generating predictions...")
    predictions = model_trainer.predict(model, X_test, price_bounds, train)
    
    # Create submission
    print("💾 Creating submission...")
    submission_path = model_trainer.create_submission(test, predictions)
    
    print("=" * 50)
    print(f"🎉 PIPELINE COMPLETED!")
    print(f"📊 CV SMAPE: {cv_score:.2f}%")
    print(f"📄 Submission: {submission_path}")
    print("🏆 UPLOAD TO COMPETITION PORTAL!")

if __name__ == "__main__":
    main()